WLAN Converter Android app
--------------------------
Minimal Android Studio project (Kotlin) that converts SSID lines according to mapping.
Open in Android Studio and build APK.
