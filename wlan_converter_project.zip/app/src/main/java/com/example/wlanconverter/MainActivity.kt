package com.example.wlanconverter

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val map: Map<Char, Char> = mapOf(
        '1' to 'e', 'e' to '1',
        '2' to 'd', 'd' to '2',
        '3' to 'c', 'c' to '3',
        '4' to 'b', 'b' to '4',
        '5' to 'a', 'a' to '5',
        '6' to '9', '9' to '6',
        '7' to '8', '8' to '7',
        'f' to '0', '0' to 'f'
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val input = findViewById<EditText>(R.id.input)
        val btn = findViewById<Button>(R.id.convertBtn)
        val output = findViewById<TextView>(R.id.output)

        btn.setOnClickListener {
            val lines = input.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
            val results = lines.map { convertSsid(it) }
            output.text = results.joinToString("\n")
        }
    }

    private fun convertSsid(raw: String): String {
        val s = raw.trim()
        val body = if (s.startsWith("fh_")) s.removePrefix("fh_") else s
        return "wlan" + body.map { mapChar(it) }.joinToString("")
    }

    private fun mapChar(ch: Char): Char {
        val lower = ch.lowercaseChar()
        val mapped = map[lower] ?: return ch
        return if (ch.isUpperCase()) mapped.uppercaseChar() else mapped
    }
}
